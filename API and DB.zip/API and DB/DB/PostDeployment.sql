USE [DemoDB]
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('AddUserDetails'))
BEGIN
    DROP PROCEDURE AddUserDetails
END
/****** Object:  StoredProcedure [dbo].[AddUserDetails]    Script Date: 4/22/2020 11:37:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[AddUserDetails] (
@FirstName varchar(30),
@LastName varchar(30),
@PhoneNumber nvarchar(20),
@Email nvarchar(100),
@IsActive bit,
@CreatedBy int,
@UpdatedBy int,
@returnValue int OUTPUT
)
AS
BEGIN
       Declare @UserId int;

BEGIN TRY
       
       IF NOT EXISTS (SELECT TOP 1 1 FROM [USER] WHERE [Email] = @Email)
       BEGIN
	   
				  INSERT INTO [USER] (
									 [FirstName]
								   , [LastName]
								   , [PhoneNumber]
								   , [Email]
								   , [IsActive]
								   , [CreatedDate]
								   , [CreatedBy]
								   , [UpdatedDate]
								   , [UpdatedBy]
								 )
					VALUES (@FirstName,@LastName,@PhoneNumber,@Email,@IsActive, getdate(),@CreatedBy,getDate(),@UpdatedBy)

					SELECT @userId=SCOPE_IDENTITY();
         
				SELECT @returnValue = 1;  --If Record inserted successfully
	   
				
  END
	  ELSE
	  BEGIN
		 SELECT  @returnValue = 2;  ---If Email Exist
	  END
END TRY
BEGIN CATCH
  SELECT @returnValue = 0;  --If any error
END CATCH
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('GetAllUser'))
BEGIN
    DROP PROCEDURE GetAllUser
END
/****** Object:  StoredProcedure [dbo].[GetAllUser]    Script Date: 4/22/2020 11:47:51 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetAllUser]
as
Begin 
   select u.UserID,u.FirstName,u.LastName,u.PhoneNumber,u.Email,u.IsActive,u.CreatedDate,u.CreatedBy,u.UpdatedDate,u.UpdatedBy
   from [User] u where u.IsActive=1
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('GetUserProfileByUserID'))
BEGIN
    DROP PROCEDURE GetUserProfileByUserID
END
/****** Object:  StoredProcedure [dbo].[GetUserProfileByUserID]    Script Date: 4/22/2020 11:49:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[GetUserProfileByUserID] --1
@UserID INTEGER=NULL
as
Begin 
   select u.UserID,u.FirstName,u.LastName,u.PhoneNumber,u.Email,u.IsActive,u.CreatedDate,u.CreatedBy,u.UpdatedDate,u.UpdatedBy
   from [User] u where u.UserID=@UserID and u.IsActive=1
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('UpdateUserDetails'))
BEGIN
    DROP PROCEDURE UpdateUserDetails
END

/****** Object:  StoredProcedure [dbo].[UpdateUserDetails]    Script Date: 4/22/2020 11:50:34 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[UpdateUserDetails] 
(
@UserID int,
@FirstName varchar(30),
@LastName varchar(30),
@PhoneNumber nvarchar(20),
@Email nvarchar(100),
@IsActive bit,
@CreatedBy int,
@UpdatedBy int,
@returnValue int OUTPUT
)
AS
BEGIN  

       Declare @RecordCount int;
       Declare @Account int;
       Declare @Count int;
       set @Count=1
 BEGIN TRY

   IF EXISTS (SELECT TOP 1 1 FROM [USER] WHERE [Email] = @Email)
BEGIN 
	            Update [USER] SET
                [FirstName]=@FirstName
              , [LastName]=@LastName
              , [PhoneNumber]=@PhoneNumber
              , [Email]=@Email
			  , [IsActive]=@IsActive
              --, [CreatedDate]=getdate() 
			  --, [CreatedBy]=@CreatedBy
			  , [UpdatedDate]=getdate() 
			  ,[UpdatedBy]=@UpdatedBy
               where [UserID]=@UserID      
                             	    
              SELECT @returnValue = 1; --If Record updated successfully
      END
   ELSE 
   Begin 
		   Declare @UserIDChk int = 0;
		   select @UserIDChk=isnull(userid,0) FROM [USER] WHERE [Email]=@Email		

		    IF @UserIDChk<>@UserId
			BEGIN 
	            Update [USER] SET
                [FirstName]=@FirstName
              , [LastName]=@LastName
              , [PhoneNumber]=@PhoneNumber
              , [Email]=@Email
			  , [IsActive]=@IsActive
              --, [CreatedDate]=getdate() 
			  --, [CreatedBy]=@CreatedBy
			  , [UpdatedDate]=getdate() 
			  ,[UpdatedBy]=@UpdatedBy
                where [UserID]=@UserID  

		    SELECT @returnValue = 1; --If Record updated successfully

		   END
   End  

END TRY
BEGIN CATCH
  SELECT @returnValue = 0;  --If any error
END CATCH
	 
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('DeleteUserDetails'))
BEGIN
    DROP PROCEDURE DeleteUserDetails
END
/****** Object:  StoredProcedure [dbo].[DeleteUserDetails]    Script Date: 4/22/2020 11:51:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[DeleteUserDetails] 
(
@UserID int,
@UpdatedBy int,
@returnValue int OUTPUT
)
AS
BEGIN  
       Declare @Count int;
       set @Count=1
 BEGIN TRY

   IF EXISTS (SELECT TOP 1 1 FROM [USER] WHERE UserID<>0)
	BEGIN 
	            Update [USER] SET
			      [IsActive]=0
              --, [CreatedDate]=getdate() 
			  --, [CreatedBy]=@CreatedBy
			  , [UpdatedDate]=getdate() 
			  ,[UpdatedBy]=@UpdatedBy
               where [UserID]=@UserID      
                             	    
              SELECT @returnValue = 1; --If Record updated successfully
      END 

END TRY
BEGIN CATCH
  SELECT @returnValue = 0;  --If any error
END CATCH
	 
END
GO

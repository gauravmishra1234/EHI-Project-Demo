--create database DemoDB
USE [DemoDB]
GO
/****** Object:  Table [dbo].[User]    Script Date: 4/22/2020 11:57:41 PM ******/
if exists (select * from [DemoDB].sys.tables where name = 'User')
DROP TABLE [dbo].[User]
GO
/****** Object:  Table [dbo].[User]    Script Date: 4/22/2020 11:57:41 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[PhoneNumber] [varchar](20) NULL,
	[Email] [nvarchar](100) NULL,
	[IsActive] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[UpdatedBy] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
truncate table [dbo].[User]
SET IDENTITY_INSERT [dbo].[User] ON 

INSERT [dbo].[User] ([UserID], [FirstName], [LastName], [PhoneNumber], [Email], [IsActive], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (1, N'Ashish', N'Sahu', N'8744991785', N'asahu@gmail.com', 1, CAST(N'2020-04-22T00:37:40.870' AS DateTime), 1, CAST(N'2020-04-22T09:48:27.573' AS DateTime), 1)
INSERT [dbo].[User] ([UserID], [FirstName], [LastName], [PhoneNumber], [Email], [IsActive], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (2, N'Keshav', N'Singh', N'1234567890', N'Keshav@gmail.com', 1, CAST(N'2020-04-22T05:34:33.780' AS DateTime), 1, CAST(N'2020-04-22T09:48:23.773' AS DateTime), 2)
INSERT [dbo].[User] ([UserID], [FirstName], [LastName], [PhoneNumber], [Email], [IsActive], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (3, N'Gaurav', N'Mishra', N'4444444888', N'gmishra@gmail.com', 0, CAST(N'2020-04-22T09:19:54.137' AS DateTime), 0, CAST(N'2020-04-22T09:50:33.493' AS DateTime), 3)
INSERT [dbo].[User] ([UserID], [FirstName], [LastName], [PhoneNumber], [Email], [IsActive], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (4, N'adfaafaadsf', N'adfa', N'99999999', N'ashish@gmail.com', 1, CAST(N'2020-04-22T09:21:08.027' AS DateTime), 0, CAST(N'2020-04-22T09:48:31.847' AS DateTime), 4)
INSERT [dbo].[User] ([UserID], [FirstName], [LastName], [PhoneNumber], [Email], [IsActive], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (5, N'Gaurav', N'Mishra', N'44444444999', N'gmishra@gmail.com', 0, CAST(N'2020-04-22T09:49:17.983' AS DateTime), 0, CAST(N'2020-04-22T09:57:19.460' AS DateTime), 5)
INSERT [dbo].[User] ([UserID], [FirstName], [LastName], [PhoneNumber], [Email], [IsActive], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (6, N'gjgjhgjhg', N'jygjyghg', N'99999999', N'45667@gmail.com', 1, CAST(N'2020-04-22T09:49:43.403' AS DateTime), 0, CAST(N'2020-04-22T09:49:43.403' AS DateTime), 0)
SET IDENTITY_INSERT [dbo].[User] OFF


